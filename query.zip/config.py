#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2025.07.25
# @Author : 王沁桐(3636617336@qq.com)
# @File : config.py
# @Description : 


db_config = {
    "host" : "localhost",
    "port" : 3306,
    "user" : "root",
    "password" :"123456",
    "database" : "employees",
    "autocommit" : True
}